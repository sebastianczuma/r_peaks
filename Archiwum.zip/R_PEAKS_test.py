import numpy as np
import R_PEAKS


#which = 'butterworth'
which = 'movAverage'
#which = 'savGol'
#which = 'wavelet'

'-----------------------------------------------------------------------------'


file_name = np.array([100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 111, 112, 113, 114, 115, 116, 117, 118, 119, 121, 122, 123, 124, 200, 201, 202, 203, 205, 207, 208, 209, 210, 212, 213, 214, 215, 217, 219, 220, 221, 222, 223, 228, 230, 231, 232, 233, 234])

for i in range(0, len(file_name)):
    ecg_filtered = np.load('ECG_BASELINE/ref/out_'+str(which)+'/'+str(file_name[i])+'.npy')
    fs = np.load('ECG_BASELINE/ref/out_signalInfo/'+str(file_name[i])+'freq.npy')
    
    #t = np.load('ECG_BASELINE/ref/out_signalInfo/'+str(file_name[i])+'time.npy')
    #milivolty
    #ecg_filtered = ecg_filtered*1000

    r_value, r_index = R_PEAKS.FUNC_r_detection(ecg_filtered, fs)

    #np.save('R_PEAKS/ref/R_out_'+str(which)+'/R_index/r_index'+str(file_name[i])+'.npy', r_index)
    #np.save('R_PEAKS/ref/R_out_'+str(which)+'/R_value/r_value'+str(file_name[i])+'.npy', r_value)

#r_index = np.load('R_PEAKS/ref/R_out_'+str(which)+'/R_index/r_index'+str(file_name[i])+'.npy')
#r_value = np.load('R_PEAKS/ref/R_out_'+str(which)+'/R_value/r_value'+str(file_name[i])+'.npy')

#R_PEAKS.PRINT_r(ecg_filtered, r_index, r_value)
ecg_filtered = ecg_filtered[0:9340]
R_PEAKS.PRINT_all(ecg_filtered, fs)







