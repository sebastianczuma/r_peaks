src/R_PEAKS.py: funkcje szukające załamków R.
Najważniejsza jest FUNC_r_detection(ecg_filtered, fs). Zwraca odpowiednio indeksy oraz wartości wykrytych załamków. Jako parametry przyjmuje przefiltrowany przez Dominikę sygnał oraz jego częstotliwość (z ECG_BASELINE/ref/out_signalInfo).
Przy okazji dodałem tez wykrywanie granic QRS oraz załamka S ale nie gwarantuję, że są one wykrywane dokładnie. Nie siedziałem nad tym długo i nie sprawdzałem dokładności.
Na końcu znajdują się funkcje do rysowania poszczególnych etapów działania algorytmu.
Opisy funkcji znajdują się w kodzie.

src/R_PEAKS_test.py: przykład odczytu przefiltrowanych sygnałów, użycia funkcji FUNC_r_detection i rysowania wykresów.